# BrickBreakers

## Description

Assignment 2 of DASS course: Replicating the classic brick breakers game on terminal using just color text library.

## Controls
- <kbd>A</kbd>: move paddle left 
- <kbd>D</kbd>: move paddle right 
- <kbd>Q</kbd>: quit
- <kbd>E</kbd>: shoot (bonus: todo)

*Note: The controls are force-based. You do not need to press them continuously to achieve motion. Just like an actual propulsion system :)*

---
